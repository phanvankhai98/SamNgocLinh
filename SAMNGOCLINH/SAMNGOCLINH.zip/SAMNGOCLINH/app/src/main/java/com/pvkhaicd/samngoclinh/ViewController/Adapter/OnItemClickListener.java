package com.pvkhaicd.samngoclinh.ViewController.Adapter;

public interface OnItemClickListener {
    void onItemClicked(int position);
}
